
angular.module('norg.service')
    .service('norgUtils', [function(){
        
        var self = this;
        
        self.deleteNullAndWhitespaceProperties = function(obj){
            var newObj = {};
            angular.forEach(obj, function(value, key){
                if (!self.isNullOrWhitespace(value)) {
                    newObj[key] = value;
                }
            }, newObj);
            return newObj;
        };

        self.isNullOrWhitespace = function(value){
            return value == null || (angular.isString(value) && value.match(/^\s*$/) != null);
        };
        
    }]);