
angular.module('norg.login', ['norg.service', 'ngMessages'])
	.controller('loginCtrl', ['$rootScope', '$scope','$http', '$location', 'sessionService', 'authenticationService', 'locationService',
		function($rootScope, $scope, $http, $location, sessionService, authenticationService, locationService){

			$scope.title = 'Logg inn';

			$scope.authenticationError = false;
			$scope.serverError = false;
			$scope.pendingRequest = false;

			var callback = function(authResponse){
				switch(authResponse.status) {
					case 200:
						$scope.authenticationError = false;
						locationService.redirectToLoginReturnUrl();
						break;
					case 401:
						$scope.authenticationError = true;
						break;
					default:
						$scope.serverError = true;
				}
				$scope.pendingRequest = false;
			};


			$scope.login = function() {
				$scope.pendingRequest = true;
				$scope.authenticationError = false;
				$scope.serverError = false;
				authenticationService.authenticate($scope.credentials, callback);
			};
	}]);
