
angular.module('norg.service', []);
