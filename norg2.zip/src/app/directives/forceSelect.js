angular.module('norg').directive('forceSelect', forceSelect);
function forceSelect() {
  function postLink(scope, element, attrs, autoComplete) {

    function getInput() {
      return element.find('input').eq(0);
    }

    var listener = scope.$watch(getInput, function (input) {

      if(input.length) {
        listener(); // self release

        var ngModel = input.controller('ngModel');


        // sjekker om autcomplete er ikke null og finnes i listen
        input.on('blur', function () {
          if(!autoComplete.scope.selectedItem && ngModel.$modelValue) {
            scope.$applyAsync(ngModel.$setValidity('required', false));
          }
        });
      }
    })

  }

  return {
    link: postLink,
    require: 'mdAutocomplete',
    restrict: 'A'
  };
}
