angular.module('norg')
    .factory('arbeidsfordelingFactory', ['$http', '$cacheFactory','$interval', function($http, $cacheFactory, $interval){


        var urlBase = '/norg2/api/v1/arbeidsfordeling';
        var arbeidsfordelingFactory = {};

        var cache = $cacheFactory('cacheArbeidsfordelinger');

        // oppdaterer arbeidsfordelinger-cache
        arbeidsfordelingFactory.updateCache = function(){
          cache.remove(urlBase);
          arbeidsfordelingFactory.getArbeidsfordelinger();
        };

        // oppdaterer cache hvert 5.min
        $interval(function () {
            arbeidsfordelingFactory.updateCache();
        }, 1000*60*5);


        function getArbeidsfordelingerForEnhetRoute(enhetId) {
            return '/norg2/api/v1/enhet/'+enhetId+'/arbeidsfordeling';
        }

        // GET: Arbeidsfordelinger for en enhet
        arbeidsfordelingFactory.getArbeidsfordelingerForEnhet = function(enhetId){
            return $http({method: 'GET', url: getArbeidsfordelingerForEnhetRoute(enhetId), cache: false});
        };


        // GET: Henter alle arbeidsfordelinger
        arbeidsfordelingFactory.getArbeidsfordelinger = function(){
         return $http({method: 'GET', url:urlBase ,cache:cache});
        };
        

        // PUT: Oppretter en ny arbeidsfordeling
        arbeidsfordelingFactory.setArbeidsfordeling = function(arbeidsfordeling) {
            return $http({method: 'PUT', url: urlBase, data:arbeidsfordeling,cache:false})
        };


        // POST: Utfører endringer på en arbeidsfordeling
        arbeidsfordelingFactory.updateArbeidsfordeling = function(arbId,query) {
           return $http({method: 'POST', url: urlBase+'/'+arbId, cache:false, data:query});
        };

        return arbeidsfordelingFactory;
    }]);
