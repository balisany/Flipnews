
angular.module('norg').directive('fdate', ['moment', function(moment){

    // Displays DD.MM.YYYY in the view. YYYY-MM-DD in the model
    return {
        require: 'ngModel',
        link: function(elem, $scope, attrs, ngModel){
            ngModel.$formatters.push(function(val){
                if (!val){
                    return null;
                }
                return moment(val, 'YYYY-MM-DD').format('DD.MM.YYYY');
            });
            ngModel.$parsers.push(function(val){
                if (!val) {
                    return null;
                }
                return moment(val, 'DD.MM.YYYY').format('YYYY-MM-DD');
            });
        }
    };
}]);