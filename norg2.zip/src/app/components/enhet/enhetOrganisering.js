
require('pikaday');

angular.module('norg.enhet')
    .controller('enhetOrganiseringCtrl', ['$scope', '$document', '$stateParams', '$mdDialog','$timeout', 'moment', 'organiseringFactory', 'kodeverkFactory', 'enheterFactory',
        function($scope, $document, $stateParams, $mdDialog, $timeout, moment, organiseringFactory, kodeverkFactory, enheterFactory) {

            $scope.organiseringer = [];
            $scope.pendingRequest = true;

            $scope.query = {
                orderBy : 'orgType',
                limit: 10,
                page: 1
            };

            $scope.options = {
                rowSelection: false,
                multiSelect: false,
                autoSelect: false,
                decapitate: false,
                largeEditDialog: false,
                boundaryLinks: false,
                limitSelect: false,
                pageSelect: false
            };

            $scope.limitOptions = [0,10,50,100, {
                label: 'Alle',
                value: function(){
                    return $scope.organiseringer.length;
                }
            }];

            $scope.showMessage = function(msg){
    					$scope.message = msg;
    					$scope.status = true;

    					$timeout(function(){
    						$timeout(function(){
    							$scope.status = false;
    						},1000);
    					},1500);
    				};


            var currentEnhetNr = $stateParams.enhetNr;


            function mapOrganisering(org){
                var isEnhetOver = org.organiserer.nr === currentEnhetNr;
                return {
                    id : org.id,
                    orgType: org.orgType,
                    nivaa: isEnhetOver ? "OVER" : "UNDER",
                    eNr: isEnhetOver ? org.organisertUnder.nr : org.organiserer.nr,
                    eNavn: isEnhetOver ? org.organisertUnder.navn : org.organiserer.navn,
                    fra: org.fra,
                    til: org.til
                };
            }

            $scope.addOrganiseringToTable = function(newOrganisering){
                var mappedOrganisering = mapOrganisering(newOrganisering);
                $scope.organiseringer.push(mappedOrganisering);
            };

            $scope.updateOrganiseringInTable = function(updatedOrganisering) {
                var idOfUpdated = updatedOrganisering.id;
                var mappedOrganisering = mapOrganisering(updatedOrganisering);
                var index = $scope.organiseringer.map(function(org){return org.id;}).indexOf(idOfUpdated);
                $scope.organiseringer[index] = mappedOrganisering;
            };


            function mapAllOrganiseringer(data){
                var mappedOrganiseringer = [];

                angular.forEach(data, function(org){
                    mappedOrganiseringer.push(mapOrganisering(org));
                });
                $scope.organiseringer = mappedOrganiseringer;
                $scope.pendingRequest = false;
            }

            $scope.updateCache = function(){
                init();
            };


            var excelStyle= {
                headers:true,
                rows:{1:{style:{Font:{Color:"#3e3832"}}}},
                columns:[
                    {columnid:'Organiseringstype', width:120},
                    {columnid:'Niva', width:100},
                    {columnid:'Enhetsnummer', width:100},
                    {columnid:'Enhetsnavn', width:300},
                    {columnid:'GyldigFra', width:120},
                    {columnid:'GyldigTil', width:120}
                ],
                cells:{1:{1:{
                    style:{Font:{Color:"#3e3832"}}
                }}}
            };

            $scope.exportToExcel = function(param){
                alasql('SELECT orgType AS Organiseringstype, nivaa as Niva, eNr AS Enhetsnummer, eNavn AS Enhetsnavn, fra AS GyldigFra, til AS gyldigTil INTO XLS("organiseringer-enhet-'+currentEnhetNr+'.xls",?) FROM ?',[excelStyle,param]);
            };

            function init() {
                organiseringFactory.getOrganiseringer($stateParams.enhetNr).then(function(res){
                    mapAllOrganiseringer(res.data);
                }, function(error){
                    console.log("Fant ikke enhet");
                    $scope.pendingRequest = false;
                });
            }
            init();



            $scope.showOrganiseringModal = function(enhet, organisering) {
                $mdDialog.show({
                        controller: organiseringModalController,
                        locals:{
                            parentScope : $scope,
                            currentEnhet: enhet,
                            existingOrganisering: organisering
                        },
                        onComplete: afterModalAnimation,
                        templateUrl: './app/components/enhet/organisering-modal.html',
                        clickOutsideToClose: false
                    });

                function afterModalAnimation(scope) {
                    scope.initDatePickers();
                }
            };

            // organiseringModalController.$inject = ['$scope', '$mdDialog', 'parentScope', 'currentEnhet', 'existingOrganisering'];
            /*
             * ORGANISERING MODAL CONTROLLER
             */
            function organiseringModalController($scope, $mdDialog, parentScope, currentEnhet, existingOrganisering) {
                var isEditExisting = existingOrganisering ? true : false;
                $scope.thisEnhet = currentEnhet.navn+" ("+currentEnhet.enhetNr+")";

                $scope.newOrganisering = {};
                $scope.orgTyperKodeverk = [];
                $scope.enheter = [];

                $scope.apiErrors = {};

                $scope.validateEnhet = validateEnhet;
                $scope.validateOrganiseringKodeverk = validateOrganiseringKodeverk;

                $scope.orgEnhet = "";

                $scope.enhetSearch = enhetSearch;


                function validateOrganiseringKodeverk(kodeverk) {
                    kodeverkFactory.isValidKodeverk(kodeverk, $scope.newOrganisering.orgType)
                        .then(function(kode){
                            $scope.organiseringForm[kodeverk].$setValidity('kodeverk', kode.isValid);
                            $scope.organiseringForm.orgType.$setValidity("apiError", true);
                        }, function(){
                        });
                }

                function validateEnhet() {
                    enheterFactory.isEnhetValidAsync($scope.orgEnhet)
                        .then(function(isValid){
                            $scope.organiseringForm.enhet.$setValidity('enhetExists', isValid);
                        }, function(){
                        });
                }

                function enhetSearch (query){
                    return query ? $scope.enheter.filter(createEnhetFilter(query)) : $scope.enheter;
                }

                function createEnhetFilter(query){
                    var regExp = new RegExp(query, "i");
                    return function filterFunc(enhet) {
                        return regExp.test(enhet.navn) || regExp.test(enhet.nr);
                    };
                }

                $scope.onFraDatoChanged = function() {
                    $scope.tilDato.setMinDate($scope.fraDato.getMoment().add(1, 'days').toDate());
                };
                $scope.onTilDatoChanged = function(){
                    $scope.fraDato.setMaxDate($scope.tilDato.getMoment().subtract(1, 'days').toDate());
                };

                $scope.closeModal = function() {
                    $mdDialog.cancel();
                };

                function showServerErrors(data){
                    if (Array.isArray(data)){
                        angular.forEach(data, function(error){
                            $scope.organiseringForm[error.field].$setValidity("apiError", false);
                            $scope.apiErrors[error.field] = error.message;
                        });
                    } else {
                        $scope.isOrganiseringFormError = true;
                        var message = data.message;
                        if (message && message.trim() !== '') {
                            $scope.organiseringFormError = message;
                        } else {
                            $scope.organiseringFormError = "En feil oppstod";
                        }
                    }
                }

                $scope.submit = function(){
                    if ($scope.orgNivaa === "OVER") {
                        $scope.newOrganisering.organiserer = {
                            nr: currentEnhet.enhetNr
                        };
                        $scope.newOrganisering.organisertUnder = {
                            nr: $scope.orgEnhet
                        };
                    } else {
                        $scope.newOrganisering.organiserer = {
                            nr: $scope.orgEnhet
                        };
                        $scope.newOrganisering.organisertUnder = {
                            nr: currentEnhet.enhetNr
                        };
                    }
                    if (isEditExisting) {
                        organiseringFactory.update(existingOrganisering.id, $scope.newOrganisering).then(function(res){

                            parentScope.updateOrganiseringInTable(res.data);
                            parentScope.showMessage("Organisering oppdatert");
                            $mdDialog.cancel();

                        }, function(res){
                            showServerErrors(res.data);
                        });
                    } else {
                        organiseringFactory.create($scope.newOrganisering).then(function (res) {
                            parentScope.addOrganiseringToTable(res.data);
                            parentScope.showMessage("Opprettet ny organisering");
                            $mdDialog.cancel();
                        }, function (res) {
                            showServerErrors(res.data);
                        });
                    }
                };

                $scope.repositionDatePicker = function(pika){
                    var parentScrollOffset = Math.abs(parseInt($document[0].body.style.top));
                    parentScrollOffset = parentScrollOffset ? parentScrollOffset : 0;
                    var modalInputOffset = pika.el.offsetTop;
                    pika.el.style.top = parentScrollOffset+modalInputOffset+'px';
                };

                $scope.initDatePickers = function() {
                    if (isEditExisting) {
                        var gyldigFraDato = moment(existingOrganisering.fra, "YYYY-MM-DD").toDate();
                        var gyldigTilDato = moment(existingOrganisering.til, "YYYY-MM-DD").toDate();
                        $scope.tilDato.setDate(gyldigTilDato);
                        $scope.fraDato.setDate(gyldigFraDato);
                    }
                };

                function init(){
                    $scope.isOrganiseringFormError = false;
                    if (isEditExisting) {
                        $scope.title = 'Rediger organisering';
                        $scope.btnName = 'Lagre endringer';

                        $scope.newOrganisering.orgType = existingOrganisering.orgType;
                        $scope.orgEnhet = existingOrganisering.eNr;
                        $scope.orgNivaa = existingOrganisering.nivaa;

                        $scope.newOrganisering.fra = existingOrganisering.fra;
                        $scope.newOrganisering.til = existingOrganisering.til;

                    } else {
                        $scope.title = "Opprett ny organisering for "+$scope.thisEnhet;
                        $scope.btnName = "Opprett organisering";

                        $scope.orgNivaa = "UNDER";
                    }
                    $scope.orgTyperKodeverk = kodeverkFactory.getOrganiseringer();

                    enheterFactory.getEnheter().then(function(res){
                        angular.forEach(res.data, function(enhet){
                            $scope.enheter.push({
                                nr : enhet.enhetNr,
                                navn : enhet.navn
                            });
                        });
                    }, function(res){

                    });
                }
                init();
            }

        }]);
