angular.module('norg.arbeidsfordeling', ['ngMaterial', 'ngMessages'])
	.controller('arbeidsfordelingCtrl',
		[ '$scope',
			'$document',
			'arbeidsfordelingFactory',
			'kodeverkFactory',
			'enheterFactory',
			'$timeout',
			'moment',
			'$mdDialog',
			'norgUtils',
			function($scope, $document, arbeidsfordelingFactory, kodeverkFactory, enheterFactory, $timeout, moment, $mdDialog, norgUtils){

				$scope.title = 'Arbeidsfordelinger';
				$scope.APIstatus = "";
				$scope.arbeidsfordelinger = [];

				$scope.updateCache = function(){
						arbeidsfordelingFactory.updateCache();
						init();
				};

				function init(){
				arbeidsfordelingFactory.getArbeidsfordelinger().then(function(res){
					$scope.arbeidsfordelinger = res.data;
				}, function(error){
					$scope.APIstatus = "Feil api: " + error.message;
				});
			} init();


				// callback status fra modal
				$scope.status = '';


				// default filterverdi av input-felter
				$scope.filter = {
					enhetsnr:'',
					geografisknedsfelt: '',
					arkivtema: '',
					behandlingstype:'',
					behandlingstema:''
				};

				// md-table innstillinger
				$scope.limitOptions = [10,50,100, {
					label: 'Alle',
					value: function(){
						return $scope.arbeidsfordelinger.length;
					}
				}];

				$scope.query = {
					order: 'id',
					limit: 10,
					page: 1
				};

				$scope.options = {
					rowSelection: false,
					multiSelect: false,
					autoSelect: false,
					decapitate: false,
					largeEditDialog: false,
					boundaryLinks: false,
					limitSelect: false,
					pageSelect: false
				};

				$scope.showMessage = function(msg){
					$scope.message = msg;
					$scope.status = true;

					$timeout(function(){
						$timeout(function(){
							$scope.status = false;
						},1500);
					},2000);
				};


				//	input-filter

				$scope.enhetnrFilter = function(arbeidsfordeling) {
					var regExp = new RegExp($scope.filter.enhetsnr, "i");
					return regExp.test(arbeidsfordeling.enhetNavn) || regExp.test(arbeidsfordeling.enhetNr);
				};

				$scope.geografisknedsfeltFilter = function(arbeidsfordeling) {
					var regExp = new RegExp($scope.filter.geografisknedsfelt, "i");
					return regExp.test(arbeidsfordeling.geo);
				};

				$scope.arkivtemaFilter = function(arbeidsfordeling) {
					var regExp = new RegExp($scope.filter.arkivtema, "i");
					return regExp.test(arbeidsfordeling.ark);
				};

				$scope.behandlingstypeFilter = function(arbeidsfordeling) {
					var regExp = new RegExp($scope.filter.behandlingstype, "i");
					return regExp.test(arbeidsfordeling.beht);
				};

				$scope.behandlingstemaFilter = function(arbeidsfordeling) {
					var regExp = new RegExp($scope.filter.behandlingstema, "i");
					return regExp.test(arbeidsfordeling.behtema);
				};



				$scope.searchArkivtema = "";
				$scope.searchBehnadlingstype = "";
				$scope.searchBehtema = "";
				$scope.searchArkivtema = "";

				$scope.toggleLimitOptions = function () {
					$scope.limitOptions = $scope.limitOptions ? undefined : [5, 10, 15];
				};

				$scope.addArbeidsfordelingToTable = function(arbeidsfordeling){
					$scope.arbeidsfordelinger.push(arbeidsfordeling);
				};

				$scope.updateArbeidsfordelingInTable = function(arbeidsfordeling) {
					var idOfUpdated = arbeidsfordeling.id;
					var index = $scope.arbeidsfordelinger.map(function(arb){return arb.id;}).indexOf(idOfUpdated);
					$scope.arbeidsfordelinger[index] = arbeidsfordeling;
				};

				$scope.updateKodeverkTooltip = function(kodeverk, kodeNavn){
					if (kodeNavn) {
						kodeverkFactory.getTermForKodeverk(kodeverk, kodeNavn).then(function (term) {
							$scope.kodeverkTooltip = term;
						});
					} else {
						$scope.kodeverkTooltip = "";
					}
				};

				var excelStyle= {
					headers:true,
					rows:{1:{style:{Font:{Color:"#3e3832"}}}},
					columns:[
						{columnid:'GeografiskNedslagsfelt', width:100},
						{columnid:'Arkivtema', width:120},
						{columnid:'Behandlingstype', width:120},
						{columnid:'Behandlingstema', width:120},
						{columnid:'Enhetsnummer', width:100},
						{columnid:'GyldigFra', width:120},
						{columnid:'GyldigTil', width:120}
					],
					cells:{1:{1:{
						style:{Font:{Color:"#3e3832"}}
					}}}
				};

				$scope.exportToExcel = function(param){
					alasql('SELECT geo AS GeografiskNedslagsfelt, ark as Arkivtema, beht AS Behandlingstype, behtema AS Behandlingstema, enhetNr AS Enhetsnummer, fra AS GyldigFra, til AS GyldigTil INTO XLS("arbeidsfordelinger.xls",?) FROM ?',[excelStyle,param]);
				};


				$scope.showArbeidsfordelingModal = function(arbeidsfordeling) {
					$mdDialog.show({
						controller: arbeidsfordelingModalController,
						templateUrl: './app/components/arbeidsfordeling/arbeidsfordeling-modal.html',
						locals: {
							parentScope : $scope,
							existingArbeidsfordeling: arbeidsfordeling
						},
						clickOutsideToClose:false,
						onComplete: afterModalAnimation
					});

					function afterModalAnimation(scope){
						scope.initDatePickers();
					}
				};


				function arbeidsfordelingModalController($scope, $mdDialog, parentScope, existingArbeidsfordeling) {
					var isEditExisting = existingArbeidsfordeling ? true : false;
					$scope.arbeidsfordeling = {};
					$scope.arkivtemaer = kodeverkFactory.getArkivtemaer();
					$scope.behtemaer = kodeverkFactory.getBehandlingstema();
					$scope.behtyper = kodeverkFactory.getBehandlingstyper();
					$scope.enheter = [];

					$scope.apiErrors = {};

					$scope.validateKodeverk = validateKodeverk;

					function validateKodeverk(kodeverk){
						kodeverkFactory.isValidKodeverk(kodeverk, $scope.arbeidsfordeling[kodeverk])
							.then(function(kode){
								if (kode.navn != null && kode.navn.trim() !== ''){
									$scope.arbeidsfordelingForm[kodeverk].$setValidity('kodeverk', kode.isValid);
									$scope.arbeidsfordelingForm[kodeverk].$setValidity("apiError", true);
								} else {
									// Allow null
									$scope.arbeidsfordelingForm[kodeverk].$setValidity('kodeverk', true);
									$scope.arbeidsfordelingForm[kodeverk].$setValidity("apiError", true);
								}
							});
					}

					$scope.enhetSearch = function(query) {
						return query ? $scope.enheter.filter(createEnhetFilter(query)) : $scope.enheter;
					};

					function createEnhetFilter(query){
						var regExp = new RegExp(query, "i");
						return function filterFunc(enhet) {
							return regExp.test(enhet.navn) || regExp.test(enhet.nr);
						};
					}

					$scope.validateEnhet = function() {
						enheterFactory.isEnhetValidAsync($scope.arbeidsfordeling.enhetNr)
							.then(function (isValid) {
								$scope.arbeidsfordelingForm.enhetNr.$setValidity('enhetExists', isValid);
							}, function () {
							});
					};

					$scope.repositionDatePicker = function(pika){
						var parentScrollOffset = Math.abs(parseInt($document[0].body.style.top));
						parentScrollOffset = parentScrollOffset ? parentScrollOffset : 0;
						var modalInputOffset = pika.el.offsetTop;
						pika.el.style.top = parentScrollOffset+modalInputOffset+'px';
					};

					$scope.initDatePickers = function () {
						if (isEditExisting) {
							var gyldigFraDato = moment(existingArbeidsfordeling.fra, "YYYY-MM-DD").toDate();
							var gyldigTilDato = moment(existingArbeidsfordeling.til, "YYYY-MM-DD").toDate();
							$scope.tilDato.setDate(gyldigTilDato);
							$scope.fraDato.setDate(gyldigFraDato);
						}
					};
					$scope.onFraDatoChanged = function() {
						$scope.tilDato.setMinDate($scope.fraDato.getMoment().add(1, 'days').toDate());
					};
					$scope.onTilDatoChanged = function(){
						$scope.fraDato.setMaxDate($scope.tilDato.getMoment().subtract(1, 'days').toDate());
					};

					$scope.cancel = function() {
						$mdDialog.cancel();
					};

					function showServerErrors(data){
						if (Array.isArray(data)){
							angular.forEach(data, function(error){
								$scope.arbeidsfordelingForm[error.field].$setValidity("apiError", false);
								$scope.apiErrors[error.field] = error.message;
							});
						} else {
							$scope.isArbeidsfordelingFormError = true;
							var message = data.message;
							if (message && message.trim() !== '') {
								$scope.arbeidsfordelingFormError = message;
							} else {
								$scope.arbeidsfordelingFormError = "En feil oppstod";
							}
						}
					}
					$scope.save = function() {
						var arb;
						if (isEditExisting) {
							arb = norgUtils.deleteNullAndWhitespaceProperties($scope.arbeidsfordeling);
							arbeidsfordelingFactory.updateArbeidsfordeling(arb.id, arb).then(function(res){
								parentScope.updateArbeidsfordelingInTable(res.data);
								parentScope.showMessage("Arbeidsfordeling oppdatert");
								$mdDialog.cancel();
							}, function(res){
								showServerErrors(res.data);
							});

						} else {
							arb = norgUtils.deleteNullAndWhitespaceProperties($scope.arbeidsfordeling);
							arbeidsfordelingFactory.setArbeidsfordeling(arb).then(function(res){
								parentScope.addArbeidsfordelingToTable(res.data);
								parentScope.showMessage("Opprettet ny arbeidsfordeling");
								$mdDialog.cancel();
							}, function(res){
								showServerErrors(res.data);
							});
						}
					};

					function init(){
						$scope.isArbeidsfordelingFormError = false;
						$scope.enhetNrDisabled = false;

						if (isEditExisting){
							$scope.arbeidsfordeling = angular.copy(existingArbeidsfordeling);
							$scope.title = "Endre arbeidsfordeling";
							$scope.btnName = "Lagre endringer";
							$scope.btnAriaLabel = "oppdater arbeidsfordeling";

						} else {
							$scope.title = "Opprett ny arbeidsfordeling";
							$scope.btnName = "Opprett arbeidsforedeling";
							$scope.btnAriaLabel = "opprett arbeidsfordeling";
						}
						enheterFactory.getEnheter().then(function(res){
							angular.forEach(res.data, function(enhet){
								$scope.enheter.push({
									nr : enhet.enhetNr,
									navn : enhet.navn
								});
							});
						}, function(res){

						});
					}
					init();
				}
			}]);
