angular.module('norg')
    .factory('kodeverkFactory', ['$http', '$q', function($http, $q){

        var urlBase = '/norg2/api/v1/kodeverk';

        var kodeverkFactory = {};

        // GET: Henter alle arkivtemaer fra kodeverket
        kodeverkFactory.getArkivtemaer = function(){
          var data = [];
          $http({method: 'GET', url:urlBase + '/arkivtemaer' ,cache:true}).then(function(res){
            angular.forEach(res.data, function(v,k){
              data.push(v);
            });
         }
         ,function(error){
              data = 0;
 							console.log("Feil med ArkivtemaerAPI");
 				});
         return data;
        };

        // GET: Henter alle Behandlingstema fra kodeverket
        kodeverkFactory.getBehandlingstema = function(){
          var data = [];
            $http({method: 'GET', url:urlBase + '/Behandlingstema' ,cache:true}).then(function(res){
              angular.forEach(res.data, function(v,k){
                data.push(v);
              });
           },function(error){
                data = 0;
                console.log("Feil med BehandlingstemaAPI");
            });
            return data;
        };


        // GET: Henter alle Behandlingstyper fra kodeverket
        kodeverkFactory.getBehandlingstyper = function(){
            var data = [];
              $http({method: 'GET', url:urlBase + '/Behandlingstyper' ,cache:true}).then(function(res){
                angular.forEach(res.data, function(v,k){
                  data.push(v);
                });
             }
             ,function(error){
                data = 0;
               	console.log("Feil BehandlingstyperAPI");
      				});
             return data;
            };

            // GET: Henter alle organivå fra kodeverket
            kodeverkFactory.getOrgnivaa = function(){
                var data = [];
                  $http({method: 'GET', url:urlBase + '/orgnivaa' ,cache:true}).then(function(res){
                    angular.forEach(res.data, function(v,k){
                      data.push(v);
                    });
                 }
                 ,function(error){
                    data = 0;
                    console.log("Feil OrgnivaaAPI");
                  });
                 return data;
                };

        // GET: Organiseringstyper
        kodeverkFactory.getOrganiseringer = function() {
            var data = [];
            $http({method: 'GET', url: urlBase+'/organisering', cache:true}).then(function(res){
                angular.forEach(res.data, function(org){
                    data.push(org);
                });
            }, function(res){
                data = 0;
            });
            return data;
        };

        kodeverkFactory.getArkivtemaerAsync = function() {
            return $http({method: 'GET', url:urlBase + '/arkivtemaer' ,cache:true});
        };

        kodeverkFactory.getBehandlingstemaAsync = function() {
            return $http({method: 'GET', url:urlBase + '/Behandlingstema' ,cache:true})
        };

        kodeverkFactory.getBehandlingstyperAsync = function() {
            return $http({method: 'GET', url:urlBase + '/Behandlingstyper' ,cache:true});
        };

        kodeverkFactory.getOrgnivaaAsync = function(){
            return $http({method: 'GET', url:urlBase + '/orgnivaa' ,cache:true});
        };

        kodeverkFactory.getOrganiseringerAsync = function(){
            return $http({method: 'GET', url: urlBase+'/organisering', cache:true})
        };

        var getKodeverkPromise = function(kodeverk){
            switch(kodeverk) {
                case 'ark':
                    return kodeverkFactory.getArkivtemaerAsync;
                case 'beht':
                    return kodeverkFactory.getBehandlingstyperAsync;
                case 'behtema':
                    return kodeverkFactory.getBehandlingstemaAsync;
                case 'orgNivaa':
                    return kodeverkFactory.getOrgnivaaAsync;
                case 'orgType':
                    return kodeverkFactory.getOrganiseringerAsync;
            }
        };
        
        kodeverkFactory.getTermForKodeverk = function(kodeverk, kodeNavn){
            var deferred = $q.defer();

            getKodeverkPromise(kodeverk)().then(function (res) {
                var foundAt = res.data.map(function (e) {
                    return e.navn
                }).indexOf(kodeNavn);
                deferred.resolve(res.data[foundAt].term);
            }, function () {
                deferred.reject(false);
            });
            return deferred.promise;
        };

        kodeverkFactory.isValidKodeverk = function(kodeverk, kodeNavn){
            var deferred = $q.defer();

            getKodeverkPromise(kodeverk)().then(function (res) {
                var foundAt = res.data.map(function (e) {
                    return e.navn
                }).indexOf(kodeNavn);
                deferred.resolve({
                        isValid : foundAt !== -1,
                        navn : kodeNavn });
            }, function () {
                deferred.reject(false);
            });
            return deferred.promise;
        };


        return kodeverkFactory;
    }]);
