
angular.module('norg').directive('nullable', [function(){

    return {
        require: 'ngModel',
        restrict: 'A',
        link: function(scope, elem, attrs, ngModel) {
            ngModel.$parsers.push(function(val){
                if (val == null || val.match(/^\s*$/) != null) {
                    return null;
                }
                return val;
            })
        }
    }
}]);
