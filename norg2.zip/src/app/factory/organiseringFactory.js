
angular.module('norg')
    .factory('organiseringFactory', ['$http', function($http){
        var organiseringFactory = {};

        var urlBase = '/norg2/api/v1/organisering';

        function getRoute(enhetNr){
            return '/norg2/api/v1/enhet/'+enhetNr+'/organisering'
        }

        // GET /api/v1/enhet/<enhetNr>/organisering
        organiseringFactory.getOrganiseringer = function(enhetNr) {
            return $http({
                method: 'GET',
                url: getRoute(enhetNr),
                cache: false
            })
        };

        // PUT Create organisering
        organiseringFactory.create = function(organisering) {
            return $http({
                method: 'PUT',
                url: urlBase,
                data: organisering,
                cache: false
            })
        };
        
        organiseringFactory.update = function(organiseringId, organisering) {
            return $http({
                method: 'POST',
                url: urlBase+'/'+organiseringId,
                data: organisering,
                cache: false
            })
        };

        return organiseringFactory;
    }]);