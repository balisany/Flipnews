//production setup
var config = {
	host:'production_ip'
}