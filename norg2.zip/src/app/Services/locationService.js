


angular.module('norg.service')
    .service('locationService', ['$rootScope', '$location', function($rootScope, $location) {

        var self = this;

        var returnUrl;

        self.redirectToUpdatedEnhet = function(enhetNr) {
            $location.path('/enhet/'+enhetNr).replace();
        };

        self.updateLoginReturnUrl = function(){
            returnUrl = $location.path();
        };

        self.redirectToLoginReturnUrl = function() {
            if (returnUrl) {
                $location.path(returnUrl).replace();
            } else {
                $location.path("/").replace();
            }
        }

    }]);