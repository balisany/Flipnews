require('angular');
require('angular-ui-router');
require('angular-aria');
require('angular-animate');
require('angular-material');
require('angular-material-data-table');
require('angular-material-icons');
// require('angular-cookies');
require('angular-messages');
require('moment');
require('moment/locale/nb');
require('angular-moment');
require('pikaday');
require('pikaday-angular');
require('./components/oversikt/oversikt');
require('./components/login/login');
require('./components/enhet/enhet');
require('./components/enhet/enhetOrganisering');
require('./components/enhet/enhetArbeidsfordeling');
require('./components/arbeidsfordeling/arbeidsfordeling');
require('./services/serviceModule');
require('./services/sessionService');
require('./services/locationService');
require('./services/authenticationService');
require('./services/utils');

var app = angular.module('norg', ['ui.router', 'ngMaterial', 'norg.login', 'norg.oversikt', 'norg.enhet', 'norg.arbeidsfordeling', 'norg.service', 'md.data.table', 'ngMdIcons', 'angularMoment', 'pikaday']);

require('./factory/enheterFactory');
require('./factory/arbeidsfordelingFactory');
require('./factory/kodeverkFactory');
require('./factory/organiseringFactory');
require('./shared/header/header');
require('./directives/dateFormat');
require('./directives/nullable');
require('./directives/forceSelect');


app.config(['$stateProvider', '$urlRouterProvider', '$httpProvider', function($stateProvider, $urlRouterProvider, $httpProvider) {

	$urlRouterProvider.otherwise("/");

	$stateProvider

	.state('oversikt', {
		url: "/",
		views : {
			"content@" : {
				templateUrl:"app/components/oversikt/oversikt.html"
			},
			"header@": {
				templateUrl:"app/shared/header/header.html"
			}
		}
	})
	.state('enhet', {
		url: '/enhet/{enhetNr}',
		views: {
			'content@' : {
				templateUrl: "app/components/enhet/enhet.html"
			},
			'header@' : {
				templateUrl : "app/shared/header/header.html"
			}
		}
	})
	.state('arbeidsfordeling', {
		url: '/arbeidsfordeling',
		views: {
			'content@' : {
				templateUrl: "app/components/arbeidsfordeling/arbeidsfordeling.html"
			},
			'header@' : {
				templateUrl : "app/shared/header/header.html"
			}
		}
	})
	.state('login', {
		url: "/login",
		views : {
			"content@" : {
				templateUrl:"app/components/login/login.html"
			},
			"header@":{
				templateUrl:"app/shared/header/header.html"
			}
		}
	});

	$httpProvider.defaults.headers.common["X-Requested-With"] = "XMLHttpRequest";
}]);



app.config(['pikadayConfigProvider', 'moment', function(pikaday, moment) {

	moment.locale("nb");
	var locales = {
		nb: {
			previousMonth : "Forrige maned",
			nextMonth : "Neste maned",
			months : ["Januar", "Februar", "Mars", "April", "Mai", "Juni", "Juli", "August", "September", "Oktober", "November", "Desember"],
			weekdays: ["Søndag", "Mandag", "Tirsdag", "Onsdag", "Torsdag", "Fredag", "Lørdag"],
			weekdaysShort: ["Sø", "Ma", "Ti", "On", "To", "Fr", "Lø"]
		}
	};

	pikaday.setConfig({
		format: "DD.MM.YYYY",
		firstDay: 1,
		defaultDate: new Date(),
		yearRange: [1900, 2100],
		i18n: locales.nb,
		locales: locales
	});
}]);
app.config(function($mdThemingProvider) {
  $mdThemingProvider.definePalette('norgPrimary', {
    '50': 'ffebee',
    '100': 'ffcdd2',
    '200': 'ef9a9a',
    '300': 'e57373',
    '400': 'dd2c00',
    '500': '506671',
    '600': '506671',
    '700': 'd32f2f',
    '800': 'c62828',
    '900': 'b71c1c',
    'A100': 'ffffff',
    'A200': 'ff5252',
    'A400': 'ff1744',
    'A700': 'd50000',
    'contrastDefaultColor': 'light',    // whether, by default, text (contrast)
                                        // on this palette should be dark or light
    'contrastDarkColors': ['50', '100', //hues which contrast should be 'dark' by default
     '200', '300', '400', 'A100'],
    'contrastLightColors': undefined    // could also specify this if default was 'dark'
  });
  $mdThemingProvider.theme('default')
    .primaryPalette('norgPrimary')
});

app.config(['$mdThemingProvider', function($mdThemingProvider){
	$mdThemingProvider.theme('default').primaryPalette('norgPrimary',{
		//'default':'400'
		'hue-2':'A100'
	}).accentPalette('deep-orange').warnPalette('deep-orange',{
		/*'default':'400', */
		'hue-1':'100',
		'hue-2':'A100',
		'hue-3':'A100'
	});
}]);


app.run(['$rootScope', 'authenticationService', 'sessionService', 'locationService', function($rootScope, authenticationService, sessionService, locationService){

	$rootScope.$on('$stateChangeSuccess', function(){
		if (!sessionService.getIsAuthenticated()) {
			authenticationService.validateToken();
		}
	});

	$rootScope.$on('$stateChangeStart', function(event, toState, toParam, fromState, fromParam){

		if (toState.name === "login" && !fromState.abstract) {
			locationService.updateLoginReturnUrl();
		}

	});

}]);
