

angular.module('norg.enhet', ['ngMaterial'])

    .controller('enhetCtrl', ['$scope', '$stateParams', '$mdDialog', 'enheterFactory', 'kodeverkFactory', 'locationService', 'moment',
        function($scope, $stateParams, $mdDialog, enheterFactory, kodeverkFactory, locationService, moment){

            $scope.id = $stateParams.enhetNr;

            $scope.apiErrors = {};

            var _enhet = {};

            var _status = {
                AKTIV: 'AKTIV',
                NEDLAGT: 'NEDLAGT',
                INAKTIV: 'INAKTIV'
            };


            $scope.currentEnhet = {};
            $scope.orgNivaaKodeverk = [];

            $scope.orgNivaaSearchText = "";



            $scope.pendingRequest = true;
            $scope.editEnabled = false;

            $scope.isNewStatusAktiv = false;
            $scope.isNewStatusNedlagt = false;

            $scope.isEnhetAktiv = false;
            $scope.isEnhetNedlagt = false;

            $scope.isEnhetFormError = false;
            $scope.enhetFormError = "";

            $scope.validateKodeverk = validateKodeverk;

            $scope.getOriginalEnhet = function(){
                return _enhet;
            };

            function updateTitle(){
                $scope.title = _enhet.navn + " ("+_enhet.enhetNr+")";
            }

            function updateEnhetStatus(){
                $scope.isEnhetAktiv = _enhet.status === _status.AKTIV;
                $scope.isEnhetNedlagt = _enhet.status === _status.NEDLAGT;
            }

            function updateDatepickers(enhet){
                var gyldigFraDato = moment(enhet.gyldigFra, "YYYY-MM-DD").toDate();
                var gyldigTilDato = moment(enhet.gyldigTil, "YYYY-MM-DD").toDate();
                $scope.tilDato.setDate(gyldigTilDato);
                $scope.fraDato.setDate(gyldigFraDato);
            }

            function updateEnhetModel(){
                angular.copy($scope.currentEnhet, _enhet);
                updateDatepickers($scope.currentEnhet);
                updateEnhetStatus();
                updateTitle();
            }
            function revertEnhetModel() {
                angular.copy(_enhet, $scope.currentEnhet);
                $scope.isEnhetFormError = false;
                updateDatepickers(_enhet);
                updateEnhetStatus();
            }

            function validateEnhet() {
                if ($scope.currentEnhet.enhetNr !== _enhet.enhetNr) {
                    enheterFactory.isEnhetValidAsync($scope.currentEnhet.enhetNr)
                        .then(function (isValid) {
                            $scope.enhetForm.enhetsnummer.$setValidity('enhetExists', !isValid);
                        }, function () {
                        });
                }else {
                    $scope.enhetForm.enhetsnummer.$setValidity('enhetExists', true);
                }
            }

            $scope.$watch('currentEnhet.enhetNr', validateEnhet);

            function validateKodeverk(kodeverk){
                kodeverkFactory.isValidKodeverk(kodeverk, $scope.currentEnhet.orgNivaa)
                    .then(function(kode){
                        $scope.enhetForm.orgNivaa.$setValidity('kodeverk', kode.isValid);
                        $scope.enhetForm.orgNivaa.$setValidity("apiError", true);
                    }, function(){
                    });
            }


            $scope.enableEditing = function(){
                $scope.editEnabled = true;
            };

            $scope.cancelEdit = function(){
                $scope.editEnabled = false;
                revertEnhetModel();
            };

            function updateEnhet(){
                enheterFactory.updateEnhet($scope.currentEnhet).then(function(res){
                    $scope.editEnabled = !$scope.editEnabled;
                    if ($scope.currentEnhet.enhetNr !== _enhet.enhetNr){
                        locationService.redirectToUpdatedEnhet($scope.currentEnhet.enhetNr);
                    }
                    updateEnhetModel();
                    $scope.isEnhetFormChanged = false;
                    $scope.isEnhetFormError = false;
                    enheterFactory.invalidCache();

                }, function(res){
                    if (Array.isArray(res.data)){
                        angular.forEach(res.data, function(error){
                            $scope.enhetForm[error.field].$setValidity("apiError", false);
                            $scope.apiErrors[error.field] = error.message;
                        });
                    } else {
                        $scope.isEnhetFormError = true;
                        var message = res.data.message;
                        if (message && message.trim() !== '') {
                            $scope.enhetFormError = res.data.message;
                        } else {
                            $scope.enhetFormError = "En feil oppstod";
                        }
                    }
                });
            }

            $scope.saveChanges = function (ev){
                if ($scope.isNewStatusAktiv || $scope.isNewStatusNedlagt){
                    $scope.showConfirm( updateEnhet, ev);
                } else {
                    updateEnhet();
                }
            };

            $scope.showConfirm = function(confirmCallback, event){
                var content = "";
                if ($scope.isNewStatusAktiv){
                    content = "Gyldig fra dato er satt tidligere enn dagens dato. Dersom du bekrefter kan ikke enheten redigeres videre.";
                } else if($scope.isNewStatusNedlagt) {
                    content = "Gyldig til dato er satt tidligere enn dagens dato. Dersom du bekrefter kan ikke enheten redigeres videre.";
                }
                var confirm = $mdDialog.confirm()
                    .title("Handlingen vil gi enheten status: "+$scope.currentEnhet.status)
                    .textContent(content)
                    .ariaLabel("bekrefetlsesmodal")
                    .targetEvent(event)
                    .cancel("Avbryt")
                    .ok("Bekreft");


                $mdDialog.show(confirm).then(function(){
                    confirmCallback();
                });
            };

            $scope.updateKodeverkTooltip = function(kodeverk, kodeNavn){
                if (kodeNavn) {
                    kodeverkFactory.getTermForKodeverk(kodeverk, kodeNavn).then(function (term) {
                        $scope.kodeverkTooltip = term;
                    });
                } else {
                    $scope.kodeverkTooltip = "";
                }
            };

            function updateStatusOfEditedEnhet(){
                $scope.isNewStatusNedlagt = $scope.tilDato.getMoment().isBefore(moment());
                $scope.isNewStatusAktiv = $scope.fraDato.getMoment().isBefore(moment()) && !$scope.isNewStatusNedlagt;

                if ($scope.isNewStatusAktiv){
                    $scope.currentEnhet.status = _status.AKTIV;
                }
                else if($scope.isNewStatusNedlagt){
                    $scope.currentEnhet.status = _status.NEDLAGT;
                } else {
                    $scope.currentEnhet.status = _status.INAKTIV;
                }
            }

            $scope.onFraDatoChanged = function() {
                $scope.tilDato.setMinDate($scope.fraDato.getMoment().add(1, 'days').toDate());
                updateStatusOfEditedEnhet();
            };

            $scope.onTilDatoChanged = function(){
                $scope.fraDato.setMaxDate($scope.tilDato.getMoment().subtract(1, 'days').toDate());
                updateStatusOfEditedEnhet();
            };


            $scope.$watch('currentEnhet', function(enhet) {
                $scope.isEnhetFormChanged = JSON.stringify(enhet) !== JSON.stringify(_enhet);
            }, true);

            function init(){
                enheterFactory.getEnhet($stateParams.enhetNr).then(function(res){
                    $scope.currentEnhet = res.data;
                    $scope.orgNivaaSearchText = res.data.orgNivaa;

                    angular.copy(res.data, _enhet);
                    $scope.pendingRequest = false;

                    updateDatepickers($scope.currentEnhet);
                    updateEnhetStatus();
                    updateTitle();

                }, function(error){
                    $scope.apiError = true;
                    $scope.pendingRequest = false;
                });

                $scope.orgNivaaKodeverk = kodeverkFactory.getOrgnivaa();

            }
            init();
        }]);
