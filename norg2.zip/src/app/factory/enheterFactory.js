angular.module('norg')
    .factory('enheterFactory', ['$http', '$q', '$cacheFactory', '$interval', function($http, $q, $cacheFactory, $interval){
        var urlBase = '/norg2/api/v1/enhet';
        var enheterFactory = {};
        var cache = $cacheFactory('cacheEnhter');

        //  oppdaterer enheter-cache ved å slette den gamle og opprette en ny cache
        enheterFactory.updateCache = function(){
          cache.remove(urlBase);
          enheterFactory.getEnheter();
        };

        //  sletter enheter-cache
        enheterFactory.invalidCache = function(){
          cache.remove(urlBase);
          console.log("invalider");
        };

        // oppdaterer cache hvert 5.min
        $interval(function () {
            enheterFactory.updateCache();
        }, 1000*60*5);


        // GET: Henter alle enheter
        enheterFactory.getEnheter = function(){
            return $http({method: 'GET', url:urlBase, cache:cache});
        };

        // GET: Henter en enhet
        enheterFactory.getEnhet = function(enhetNr) {
            return $http({method: 'GET', url: urlBase+'/'+enhetNr, cache:false});
        };

        // PUT: Oppretter en ny enhet
        enheterFactory.setEnhet = function(enhet) {
            return $http({method: 'PUT', url: urlBase, data:enhet,cache:false})
        };

        // POST: Oppdaterer eksisterende enhet
        enheterFactory.updateEnhet = function(enhet) {
            return $http({method: 'POST', url:urlBase, data:enhet, cache:false});
        };


        enheterFactory.isEnhetValidAsync = function(enhetNr) {
            var deferred = $q.defer();
            enheterFactory.getEnheter().then(function (res) {
                var foundAt = res.data.map(function (enhet) {
                    return enhet.enhetNr
                }).indexOf(enhetNr);
                deferred.resolve(foundAt !== -1);
            }, function () {
                deferred.reject(false);
            });
            return deferred.promise;
        };

        return enheterFactory;
    }]);
