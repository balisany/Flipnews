
angular.module('norg.oversikt', ['ngMaterial'])
	.controller('oversiktCtrl',[ '$scope','$document',
		'enheterFactory',
		'kodeverkFactory',
		'$timeout',
		'moment',
		'$mdDialog',
		function($scope, $document, enheterFactory,kodeverkFactory, $timeout, moment, $mdDialog){

			$scope.updateCache = function(){
				enheterFactory.updateCache();
				init();
			};
			$scope.title = 'Oversikt';
			$scope.enheter = [];
			$scope.filtertekst = "";
			$scope.modalStatus = "";
			$scope.checked=false;

			$scope.limitOptions = [10,50,100, {
				label: 'Alle',
				value: function(){
					return $scope.enheter.length;
				}
			}];

			$scope.filter = {
				status:'Alle',
				search: ''
			};

			$scope.query = {
				order: 'enhetNr',
				limit: 10,
				page: 1
			};

			$scope.options = {
				rowSelection: false,
				multiSelect: false,
				autoSelect: false,
				decapitate: false,
				largeEditDialog: false,
				boundaryLinks: false,
				limitSelect: false,
				pageSelect: false
			};

			$scope.showMessage = function(msg){
				$scope.message = msg;
				$scope.status = true;

				$timeout(function(){
					$timeout(function(){
						$scope.status = false;
					},1500);
				},2000);
			};


			$scope.enhetType = kodeverkFactory.getOrgnivaa();

			function init(){
				enheterFactory.getEnheter().then(function(res){
					$scope.enheter = res.data;
				}, function(error){
					$scope.status = "Feil api: " + error.message;
				});
			}
			init();




			$scope.updateEnheter = function(obj){
				$scope.enheter = $scope.enheter.concat(obj);
			};


			$scope.textFilter = function(enhet) {
				var regExp = new RegExp($scope.filter.search, "i");
				return regExp.test(enhet.navn) || regExp.test(enhet.enhetNr);
			};


			$scope.statusFilter = function(enhet) {
				return $scope.filter.status === 'Alle' ? true : $scope.filter.status === enhet.status;
			};

			var excelStyle= {
				headers:true,
				rows:{1:{style:{Font:{Color:"#3e3832"}}}},
				columns:[
					{columnid:'Enhetsnavn', width:400},
					{columnid:'Enhetsnummer', width:120},
					{columnid:'AntallRessurser', width:120},
					{columnid:'Status', width:120},
					{columnid:'GyldigFra', width:120},
					{columnid:'GyldigTil', width:120}
				],
				cells:{1:{1:{
					style:{Font:{Color:"#3e3832"}}
				}}}
			};
			$scope.exportToExcel = function(param){
				alasql('SELECT navn AS Enhetsnavn, enhetNr as Enhetsnummer, antallRessurser AS AntallRessurser, status AS Status, gyldigFra AS GyldigFra, gyldigTil AS GyldigTil INTO XLS("enheter.xls",?) FROM ?',[excelStyle,param]);
			};

			$scope.toggleLimitOptions = function () {
				$scope.limitOptions = $scope.limitOptions ? undefined : [5, 10, 15];
			};


			$scope.enhtNrExist = false;
			$scope.enhtNavn = "";
			// sjekker om enhetsnr finnes fra før
			$scope.findIndexOf = function(obj){
				for(var i = 0; i < $scope.enheter.length; i++){
					if(angular.equals($scope.enheter[i].enhetNr, obj)){
						$scope.enhtNrExist = true;
						$scope.enhtNavn = $scope.enheter[i].navn;
						console.log($scope.enhtNavn);
						return true;
					}
				}
				$scope.enhtNrExist = false;
				return false;
			};

			// sjekker om autocomplete har verdi
			$scope.isEmpty = function(obj){
				return !!obj;

			};

			$scope.repositionDatePicker = function(pika){
				var parentScrollOffset = Math.abs(parseInt($document[0].body.style.top));
				parentScrollOffset = parentScrollOffset ? parentScrollOffset : 0;
				var modalInputOffset = pika.el.offsetTop;
				pika.el.style.top = parentScrollOffset+modalInputOffset+'px';
			};


			$scope.onFraDatoChanged = function() {
				$scope.tilDato.setMinDate($scope.fraDato.getDate());
			};

			$scope.onTilDatoChanged = function(){
				$scope.fraDato.setMaxDate($scope.tilDato.getDate());
			};

			// avbrytter modal
			$scope.cancel = function() {
				$mdDialog.cancel();
			};

			// lagrer endringer i modal
			$scope.save = function(form) {
				var query = {
					navn: form.enhetNavn.$modelValue,
					enhetNr: form.enhetNr.$modelValue,
					orgNivaa: form.type.$modelValue,
					gyldigFra: form.fraDato.$modelValue,
					gyldigTil: form.tilDato.$modelValue
				};

				enheterFactory.setEnhet(query).then(function(res){
					$mdDialog.hide(res.data);
				},function(err){
					if(err.status === "500"){
						$scope.modalStatus = "Operasjonen ble ikke gjennomført";
					}
				});
			};

			// viser modal
			$scope.showAddModal = function(ev){
				$mdDialog.show({
						parent:angular.element(document.body),
						templateUrl: './app/components/oversikt/add-enhet-modal.html',
						controller:'oversiktCtrl',
						clickOutsideToClose:false
					})
					.then(function(res) {
						$scope.showMessage(res.navn + "  ble opprettet.");
						$scope.updateEnheter(res);
					},function(err){
					});
			};
		}]);
